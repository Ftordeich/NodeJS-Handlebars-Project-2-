// Setup express router
const { json } = require("express");
const express = require("express");
const router = express.Router();

// Middleware
// -------------------------------------------------------------------------
function addDetailsToLocals(req, res, next) {
    const cookieName ='details';
    let cookieValue = req.cookies[cookieName];
    let message;
    if (cookieValue){
        cookieValue = JSON.parse(cookieValue);
        res.locals.name = cookieValue.name;
        res.locals.address = cookieValue.address;
        res.locals.phoneNum = cookieValue.phoneNum;

    }
    else { 
        message = `Couldn't find a cookie with name = '${cookieName}'`;
        console.log(message);
    }
    next();
    



    // TODO 4) Add the name, address, and phoneNum to res.locals. The values should be
    // obtained from the "details" cookie. Be sure to take into account the fact that the cookie
    // may be undefined.

}
// -------------------------------------------------------------------------

// Route handlers
// -------------------------------------------------------------------------

// TODO 5) Modify this route handler so that the addDetailsToLocals() middleware is called first.
router.get("/", function(req, res) {

    addDetailsToLocals(req, res, function(req, res){});

    res.render("question-two-form", { name: res.locals.name, address: res.locals.address, phoneNum: res.locals.phoneNum});
});

router.post("/submit", function(req, res) {

    // TODO 1) Add three properties to this object: "name", "address", and "phoneNum". The values
    // of these properties should come from the user's form submission.
    let detailsCookie = {
        name: [req.body.name], address: [req.body.address], phoneNum: [req.body.phoneNum] };
        res.cookie("details", JSON.stringify(detailsCookie));

        if (detailsCookie.name != "" && detailsCookie.address != "" && detailsCookie.phoneNum != "") {
            res.redirect("/myDetails")
        }
        else {
        res.setToastMessage("Details saved for later");
        res.redirect("/");
        }
        
        console.log(detailsCookie);
    

   

    // TODO 2) Save the cookie to the response, with the name "details".


    // TODO 3) If the user actually typed a name, address, and phoneNum, redirect to the /myDetails route.
    // Otherwise, set a toast message saying "Details saved for later", then redirect to the / route.

    // HINT: Toast messages can be set using res.setToastMessage("...");
    // as defined by the provided "toaster" middleware, as used in labs.

});

// Show the details stored in the cookie
// TODO 7) Modify this route handler so that the addDetailsToLocals() middleware is called first.
router.get("/myDetails", function(req, res) {
    
    addDetailsToLocals(req, res, function(req, res){});
   
    res.render("question-two-details", { name: res.locals.name, address: res.locals.address, phoneNum: res.locals.phoneNum} );
});

// -------------------------------------------------------------------------

module.exports = router;