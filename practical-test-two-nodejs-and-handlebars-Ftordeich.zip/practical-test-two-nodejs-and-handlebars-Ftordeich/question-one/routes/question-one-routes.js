// Setup express router
const express = require("express");
const { get } = require("http");
const router = express.Router();
const path = require("path")

// Route handlers
// -------------------------------------------------------------------------

// TODO Your Code Here
router.get("/", function (req, res){res.sendFile(path.join(__dirname + "/../../static-page/home.html")) });
router.get("/hillary", function (req, res){res.sendFile(path.join(__dirname + "/../../static-page/hillary.html")) });
router.get("/sheppard", function (req, res){res.sendFile(path.join(__dirname + "/../../static-page/sheppard.html")) });


// -------------------------------------------------------------------------

module.exports = router;