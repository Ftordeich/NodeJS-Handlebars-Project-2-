# COMPSCI 719 Practical Test Two &ndash; node.js and Handlebars
In this test, you will put in practice the knowledge you've gained in modules 6 through 9 of the course

- There are **two** questions in this practical test. Please attempt both questions. Each question is worth **20** marks, for a total of **40** marks. These marks constitute **10%** of your overall grade for COMPSCI 719.

- This is an open book test. You may use any bound printed or handwritten notes during the test. You may also use any online or PC-based resources available to you. However: **Do not** post the questions online or otherwise attempt to allow others to provide you with the answers - including your classmates and tutors! If you do this, you will be caught, you will receive 0 marks for this assessment, and you may be subject to disciplinary action.

- **Remember**: You're given `package.json` files for each question which contain all necessary dependencies. However, you will need to recreate the `node_modules` folders yourself by running the appropriate command.

- **Important:** Make sure to read all instructions and provided source code carefully before attempting each question.


## Submission instructions
Your latest commit to the `main` branch of your GitHub Classroom repository for this assignment, as of the due date identified on Canvas, will serve as your submission for this assignment. In addition, please remember to submit your repository URL to Canvas.


## Question One &ndash; Removing duplication with Handlebars (20 marks)
Take a look at the contants of the provided [`static-page`](./static-page) folder. Inside, you'll see a set of static webpages with associated CSS and image content. Open any of the files and browse through the pages using the navbar – you'll see that the content is very similar to that which you've written in early labs for this course.

Now, open the HTML files in a text editor and compare them. You'll notice that a lot of the information in the pages is the same (for example, each page has the same JavaScript / CSS links and a very similar navbar).

For this question, add **one Handlebars layout** and **three Handlebars views** (one for each of the two famous New Zealanders, and one for the "home" page) to the appropriate locations within [`question-one`](./question-one). The layout should contain as much of the structure as possible, that's currently duplicated amongst the provided HTML files, and should be called `question-one-layout.handlebars`. The views should contain the content that's specific to each page.

Once you've done that, modify [`routes/question-one-routes.js`](./question-one/routes/question-one-routes.js) to include three route handlers:

1.	Navigating to <http://localhost:3000/> should display the home page.
2.	Navigating to <http://localhost:3000/hillary> should display the page on Edmund Hillary.
3.	Navigating to <http://localhost:3000/sheppard> should display the page on Kate Sheppard.

You will also need a way to access the CSS and image files. Place these within the [`public`](./question-one/public) folder appropriately and add code to [`question-one.js`](./question-one/question-one.js) at the marked location which enables access to this public folder.

Once these URLs are live, make sure that the links within the website all point to the correct locations.

### Hints
1. Remember that some of the content in the HTML pages is *nearly* – but not *exactly* – identical (i.e. the highlighting of the navbar items). Consider how you can make use of appropriate Handlebars functionality to extract these parts into the main layout file.

2. Remember to test your solution to make sure the user experience is *exactly* the same as the provided sample pages.

### Marking Criteria
This question will be marked as follows:

- Appropriate HTML content is served to users: *2 marks*.
- All of the above links are functional: *3 marks*.
- All links within the app are functional: *3 marks*.
- Appropriate Handlebars layout has been created: *6 marks*.
- Images and CSS files are properly served to users: *2 marks*.
- User experience is identical to the provided sample pages: *4 marks*.


## Question Two &ndash; Saving form data in a cookie (20 marks)
In this exercise, we'll complete a simple "user registration" form. Users will be able to enter their details, and will be able to register, or come back later to complete the registration form.

The existing app in the [`question-two`](./question-two) folder will present users with a registration form when navigating to `/`. The form allows them to enter their name, address and phone number. The form is set to `POST` to `/submit` – but this submission process currently does not work.

To begin this question, complete the `/submit` route handler by performing the following steps:

1. You'll see an empty `detailsCookie` object defined within the handler. To this object, add three properties: `name`, `address`, and `phoneNum`. The data for these properties should come from the three `<input>`s on the submitted form.

2. Next, at the marked location, save the `detailsCookie` (using the `res.cookie()` function). The cookie should be named `details`.

3. At the marked location, redirect the user based on their progress in filling out the form:

    - If the user has filled out all three form fields, redirect them to `/myDetails`.

    - Otherwise, redirect them to `/`, with the toast message "Details saved for later".

Next, we'll ensure that any partially-complete data is visible to the user when they load the page. Perform the following steps:

4. An empty middleware function, `addDetailsToLocals()`, is defined near the top of the file. In this middware function, before the call to `next()`, add the information in the `details` cookie to `res.locals`, so that it will be available to any Handlebars views.
   
   Remember that `req.cookies.details` might be undefined, if the user hasn't submitted the form yet – be sure to account for this.

5. Modify the `/` route handler so that the `addDetailsToLocals()` middleware function above is called before the route handler code itself.

6. Looking at the [`question-two-form`](./question-two/views/question-two-form.handlebars) view, we can see that each `<input>` is defined with `value=""`. A text `<input>`'s value determines what will be displayed in the input when the page is first loaded. Set each input's value to the appropriate piece of information sent to the view from steps 4 and 5 above.

Finally, we'll complete the `/myDetails` route handler and [`question-two-details`](./question-two/views/question-two-details.handlebars) view. Perform the following steps:

7. Modify the `/myDetails` route handler so that the `addDetailsToLocals()` middleware function above is called before the route handler code itself.

8. Add the user data from `res.locals` to the `question-two-details` view, similarly to how you performed step 6 above.

**Hint:** The following code will call the `foo()` middleware before it calls the `/hello` route handler:

```js
function foo(req, res, next) {
    // ...
    next();
}

router.get("/hello", foo, function(req, res) {
    // ...
});
```

### Marking criteria
This question will be marked as follows:

- Details cookie object populated correctly: *(3 marks)*
- Details cookie object saved correctly: *(2 marks)*
- User redirected correctly: *(5 marks)*
- `addDetailsToLocals()` middleware completed correctly: *(3 marks)*
- `addDetailsToLocals()` middleware used in correct locations: *(2 marks)*
- Information rendered in `question-two-form` view correctly: *(3 marks)*
- Information rendered in `question-two-details` view correctly: *(2 marks)*
